from django.shortcuts import render, redirect
from .models import Post, Comment
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

def index(request):
    posts = Post.objects.all().order_by('-created')
    return render(request, 'network/index.html', {'posts': posts})
